//! Враги и бесконечное выживание. Три вида «зараженных» жуков: быстрые ползуны,
//! обычные лушки и медленные громилы. Чем дольше живёшь, тем гуще поток.
//! Лимит одновременных врагов растёт со временем, но не выше 36 — защита FPS.
use crate::combat::Gun;
use crate::player::{Player, PlayerState, Shake, ARENA_R};
use crate::{theme, GameState};
use bevy::prelude::*;
use rand::Rng;
use rand::SeedableRng;
use rand_pcg::Pcg32;
use std::f32::consts::TAU;

#[derive(Component)]
pub struct Enemy {
    pub hp: f32,
    pub speed: f32,
    pub windup_time: f32,
    pub windup: f32,
    pub cd: f32,
    pub knock: Vec3,
    pub stagger: f32,
    pub radius: f32,
    pub scale: f32,
}

#[derive(Clone, Copy)]
enum Kind {
    Crawler,
    Husk,
    Brute,
}

impl Kind {
    fn stats(self) -> Enemy {
        match self {
            Kind::Crawler => Enemy { hp: 1.0, speed: 5.5, windup_time: 0.35, windup: 0.0, cd: 0.0, knock: Vec3::ZERO, stagger: 0.0, radius: 0.4, scale: 0.7 },
            Kind::Husk => Enemy { hp: 3.0, speed: 3.2, windup_time: 0.5, windup: 0.0, cd: 0.0, knock: Vec3::ZERO, stagger: 0.0, radius: 0.5, scale: 1.0 },
            Kind::Brute => Enemy { hp: 9.0, speed: 2.1, windup_time: 0.75, windup: 0.0, cd: 0.0, knock: Vec3::ZERO, stagger: 0.0, radius: 0.8, scale: 1.5 },
        }
    }
}

/// Текущий забег: время выживания — главный счёт.
#[derive(Resource, Default)]
pub struct Run {
    pub time: f32,
    pub kills: u32,
    pub best: f32,
    pub spawn_t: f32,
}

#[derive(Resource)]
pub struct RunRng(pub Pcg32);

impl Default for RunRng {
    fn default() -> Self {
        let seed = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_nanos() as u64)
            .unwrap_or(0x5EED);
        Self(Pcg32::seed_from_u64(seed))
    }
}

#[derive(Resource)]
struct EnemyAssets {
    body: Handle<Mesh>,
    mask: Handle<Mesh>,
    eye: Handle<Mesh>,
    body_mat: Handle<StandardMaterial>,
    mask_mat: Handle<StandardMaterial>,
    eye_mat: Handle<StandardMaterial>,
}

pub struct EnemyPlugin;

impl Plugin for EnemyPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<Run>()
            .init_resource::<RunRng>()
            .add_systems(Startup, setup_enemy_assets)
            .add_systems(OnEnter(GameState::Dead), record_best)
            .add_systems(
                Update,
                (tick_run, spawn_enemies, enemy_ai, reap_dead)
                    .chain()
                    .run_if(in_state(GameState::Playing)),
            );
    }
}

fn setup_enemy_assets(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
) {
    commands.insert_resource(EnemyAssets {
        body: meshes.add(Capsule3d::new(0.45, 1.0)),
        mask: meshes.add(Sphere::new(0.32)),
        eye: meshes.add(Cuboid::new(0.1, 0.16, 0.05)),
        body_mat: materials.add(StandardMaterial {
            base_color: Color::srgb(0.03, 0.03, 0.05),
            perceptual_roughness: 1.0,
            ..default()
        }),
        mask_mat: materials.add(StandardMaterial {
            base_color: theme::BONE,
            perceptual_roughness: 0.7,
            ..default()
        }),
        eye_mat: materials.add(StandardMaterial {
            base_color: theme::INFECTION,
            emissive: LinearRgba::rgb(4.0, 1.6, 0.3),
            ..default()
        }),
    });
}

fn record_best(mut run: ResMut<Run>) {
    run.best = run.best.max(run.time);
}

fn tick_run(time: Res<Time>, mut run: ResMut<Run>) {
    run.time += time.delta_secs();
}

fn spawn_enemies(
    time: Res<Time>,
    mut commands: Commands,
    assets: Res<EnemyAssets>,
    mut run: ResMut<Run>,
    mut rng: ResMut<RunRng>,
    alive: Query<(), With<Enemy>>,
) {
    run.spawn_t -= time.delta_secs();
    if run.spawn_t > 0.0 {
        return;
    }
    let cap = (8 + (run.time / 8.0) as usize).min(36);
    if alive.iter().count() >= cap {
        run.spawn_t = 0.3;
        return;
    }
    run.spawn_t = (1.3 - run.time * 0.014).max(0.28);

    let ang = rng.0.gen_range(0.0..TAU);
    let pos = Vec3::new(ang.cos(), 0.0, ang.sin()) * (ARENA_R - 2.0);
    let roll: f32 = rng.0.gen();
    let kind = if run.time > 40.0 && roll < 0.15 {
        Kind::Brute
    } else if roll < 0.55 {
        Kind::Crawler
    } else {
        Kind::Husk
    };
    let stats = kind.stats();
    let scale = stats.scale;

    commands
        .spawn((
            stats,
            Transform::from_translation(pos).with_scale(Vec3::splat(scale)),
            Visibility::default(),
        ))
        .with_children(|p| {
            p.spawn((
                Mesh3d(assets.body.clone()),
                MeshMaterial3d(assets.body_mat.clone()),
                Transform::from_xyz(0.0, 0.95, 0.0),
            ));
            p.spawn((
                Mesh3d(assets.mask.clone()),
                MeshMaterial3d(assets.mask_mat.clone()),
                Transform::from_xyz(0.0, 1.65, -0.12),
            ));
            for sx in [-0.12, 0.12] {
                p.spawn((
                    Mesh3d(assets.eye.clone()),
                    MeshMaterial3d(assets.eye_mat.clone()),
                    Transform::from_xyz(sx, 1.68, -0.42),
                ));
            }
        });
}

fn enemy_ai(
    time: Res<Time>,
    pst: Res<PlayerState>,
    mut shake: ResMut<Shake>,
    mut next: ResMut<NextState<GameState>>,
    player: Query<&Transform, With<Player>>,
    mut enemies: Query<(&mut Transform, &mut Enemy), Without<Player>>,
) {
    let dt = time.delta_secs();
    let Ok(pt) = player.single() else { return };
    let ppos = pt.translation;

    // позиции для простого расталкивания (врагов мало, O(n^2) допустимо)
    let positions: Vec<Vec3> = enemies.iter().map(|(t, _)| t.translation).collect();

    for (i, (mut tf, mut e)) in enemies.iter_mut().enumerate() {
        let to = Vec3::new(ppos.x - tf.translation.x, 0.0, ppos.z - tf.translation.z);
        let dist = to.length();
        let dir = to / dist.max(0.001);

        if e.stagger > 0.0 {
            e.stagger -= dt;
            tf.translation += e.knock * dt;
            e.knock *= (1.0 - 8.0 * dt).max(0.0);
            continue;
        }

        if dir != Vec3::ZERO {
            tf.look_to(dir, Vec3::Y);
        }

        let reach = 1.5 * e.scale + 0.6;
        if e.windup > 0.0 {
            e.windup -= dt;
            let p = 1.0 - (e.windup / e.windup_time).clamp(0.0, 1.0);
            tf.scale = Vec3::splat(e.scale) * (1.0 + 0.25 * p); // «вздувается» перед ударом
            if e.windup <= 0.0 {
                tf.scale = Vec3::splat(e.scale);
                if dist <= reach + 0.4 && pst.iframes <= 0.0 {
                    shake.0 = 0.6;
                    next.set(GameState::Dead); // один удар — и конец
                }
                e.cd = 0.9;
            }
        } else {
            e.cd -= dt;
            if dist > reach {
                tf.translation += dir * e.speed * dt;
            } else if e.cd <= 0.0 {
                e.windup = e.windup_time;
            }
        }

        let mut push = Vec3::ZERO;
        for (j, p) in positions.iter().enumerate() {
            if i == j {
                continue;
            }
            let d = tf.translation - *p;
            let d = Vec3::new(d.x, 0.0, d.z);
            let l = d.length();
            if l < 1.0 && l > 0.001 {
                push += d / l * (1.0 - l);
            }
        }
        tf.translation += push * 3.0 * dt;
    }
}

fn reap_dead(
    mut commands: Commands,
    mut run: ResMut<Run>,
    mut gun: ResMut<Gun>,
    q: Query<(Entity, &Enemy)>,
) {
    for (ent, e) in &q {
        if e.hp <= 0.0 {
            commands.entity(ent).despawn();
            run.kills += 1;
            gun.gems += 1;
        }
    }
}
