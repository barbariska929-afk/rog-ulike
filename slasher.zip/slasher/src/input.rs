//! Единый слой ввода: клавиатура/мышь (для отладки на ПК) и тач (Android)
//! превращаются в один ресурс `GameInput`. Остальной код про устройство не знает.
use bevy::input::mouse::AccumulatedMouseMotion;
use bevy::prelude::*;
use bevy::window::PrimaryWindow;

#[derive(SystemSet, Debug, Clone, PartialEq, Eq, Hash)]
pub struct InputSet;

#[derive(Resource, Default, Debug)]
pub struct GameInput {
    /// x — вправо, y — вперёд, длина <= 1
    pub move_axis: Vec2,
    /// Поворот за кадр в радианах: x — вправо, y — вниз
    pub look: Vec2,
    /// Огонь: true, пока кнопка стрельбы удерживается
    pub fire: bool,
    pub attack: bool,
    pub dash: bool,
    pub focus: bool,
    pub tap: bool,
    pub pick: Option<usize>,
}

/// Круглая сенсорная кнопка, прижатая к правому нижнему углу экрана.
#[derive(Clone, Copy)]
pub struct TouchButton {
    pub right: f32,
    pub bottom: f32,
    pub size: f32,
}

impl TouchButton {
    pub fn center(&self, w: f32, h: f32) -> Vec2 {
        Vec2::new(w - self.right - self.size * 0.5, h - self.bottom - self.size * 0.5)
    }
    pub fn hit(&self, p: Vec2, w: f32, h: f32) -> bool {
        p.distance(self.center(w, h)) <= self.size * 0.5 + 12.0
    }
}

pub const ATTACK_BTN: TouchButton = TouchButton { right: 28.0, bottom: 40.0, size: 120.0 };
pub const DASH_BTN: TouchButton = TouchButton { right: 170.0, bottom: 28.0, size: 86.0 };
pub const FOCUS_BTN: TouchButton = TouchButton { right: 40.0, bottom: 180.0, size: 86.0 };

pub struct InputPlugin;

impl Plugin for InputPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<GameInput>()
            .add_systems(Update, gather_input.in_set(InputSet));
    }
}

fn gather_input(
    time: Res<Time>,
    keys: Res<ButtonInput<KeyCode>>,
    mouse: Res<ButtonInput<MouseButton>>,
    motion: Res<AccumulatedMouseMotion>,
    touches: Res<Touches>,
    windows: Query<&Window, With<PrimaryWindow>>,
    mut input: ResMut<GameInput>,
) {
    *input = GameInput::default();
    let dt = time.delta_secs();

    // --- клавиатура / мышь ---
    let mut mv = Vec2::ZERO;
    if keys.pressed(KeyCode::KeyW) { mv.y += 1.0; }
    if keys.pressed(KeyCode::KeyS) { mv.y -= 1.0; }
    if keys.pressed(KeyCode::KeyD) { mv.x += 1.0; }
    if keys.pressed(KeyCode::KeyA) { mv.x -= 1.0; }
    input.move_axis = mv.clamp_length_max(1.0);

    let mut look = Vec2::ZERO;
    if keys.pressed(KeyCode::ArrowRight) { look.x += 1.0; }
    if keys.pressed(KeyCode::ArrowLeft) { look.x -= 1.0; }
    if keys.pressed(KeyCode::ArrowDown) { look.y += 1.0; }
    if keys.pressed(KeyCode::ArrowUp) { look.y -= 1.0; }
    look *= 2.2 * dt;
    if mouse.pressed(MouseButton::Right) {
        look += motion.delta * 0.0025;
    }
    input.look = look;

    input.fire = keys.pressed(KeyCode::KeyJ) || mouse.pressed(MouseButton::Left);
    input.attack = keys.just_pressed(KeyCode::KeyJ) || mouse.just_pressed(MouseButton::Left);
    input.dash = keys.just_pressed(KeyCode::Space);
    input.focus = keys.pressed(KeyCode::KeyF);
    input.tap = keys.just_pressed(KeyCode::Enter) || mouse.just_pressed(MouseButton::Left);
    input.pick = [KeyCode::Digit1, KeyCode::Digit2, KeyCode::Digit3]
        .iter()
        .position(|k| keys.just_pressed(*k));

    // --- тач ---
    let Ok(window) = windows.single() else { return };
    let (w, h) = (window.width(), window.height());

    for t in touches.iter_just_pressed() {
        input.tap = true;
        let p = t.position();
        if ATTACK_BTN.hit(p, w, h) { input.attack = true; }
        if DASH_BTN.hit(p, w, h) { input.dash = true; }
    }

    for t in touches.iter() {
        let s = t.start_position();
        if FOCUS_BTN.hit(s, w, h) {
            input.focus = true;
        } else if ATTACK_BTN.hit(s, w, h) {
            // палец удерживает кнопку огня — стреляем, пока он на экране
            input.fire = true;
        } else if DASH_BTN.hit(s, w, h) {
            // палец лежит на кнопке — не двигаем и не крутим камеру
        } else if s.x < w * 0.42 {
            // левая часть экрана: плавающий джойстик от точки касания
            let d = (t.position() - s) / 70.0;
            input.move_axis = Vec2::new(d.x, -d.y).clamp_length_max(1.0);
        } else {
            // правая часть: обзор перетаскиванием
            input.look += t.delta() * 0.004;
        }
    }
}
