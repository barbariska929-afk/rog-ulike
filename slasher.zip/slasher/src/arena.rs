//! Арена: круглый зал с колоннами в тумане. Освещение минимальное
//! (без теней), чтобы держать 60 FPS на среднем Android.
use crate::player::ARENA_R;
use crate::theme;
use bevy::prelude::*;
use std::f32::consts::TAU;

pub struct ArenaPlugin;

impl Plugin for ArenaPlugin {
    fn build(&self, app: &mut App) {
        app.insert_resource(GlobalAmbientLight {
            color: Color::srgb(0.45, 0.55, 0.85),
            brightness: 55.0,
            ..default()
        })
        .add_systems(Startup, spawn_arena);
    }
}

fn spawn_arena(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
) {
    let floor_mat = materials.add(StandardMaterial {
        base_color: theme::STONE,
        perceptual_roughness: 0.95,
        ..default()
    });
    commands.spawn((
        Mesh3d(meshes.add(Cylinder::new(ARENA_R, 0.5))),
        MeshMaterial3d(floor_mat),
        Transform::from_xyz(0.0, -0.25, 0.0),
    ));

    // Светящаяся печать в центре — ориентир и «душа» арены
    let sigil_mat = materials.add(StandardMaterial {
        base_color: theme::SOUL,
        emissive: LinearRgba::rgb(0.2, 0.45, 0.8),
        unlit: false,
        ..default()
    });
    commands.spawn((
        Mesh3d(meshes.add(Annulus::new(5.6, 6.0))),
        MeshMaterial3d(sigil_mat),
        Transform::from_xyz(0.0, 0.02, 0.0)
            .with_rotation(Quat::from_rotation_x(-std::f32::consts::FRAC_PI_2)),
    ));

    // Кольцо колонн с острыми навершиями
    let pillar = meshes.add(Cuboid::new(1.3, 14.0, 1.3));
    let spire = meshes.add(Cone::new(0.9, 3.0));
    let pillar_mat = materials.add(StandardMaterial {
        base_color: theme::PILLAR,
        perceptual_roughness: 0.9,
        ..default()
    });
    let n = 14;
    for i in 0..n {
        let a = i as f32 / n as f32 * TAU;
        let p = Vec3::new(a.cos(), 0.0, a.sin()) * (ARENA_R + 0.5);
        commands.spawn((
            Mesh3d(pillar.clone()),
            MeshMaterial3d(pillar_mat.clone()),
            Transform::from_translation(p + Vec3::Y * 7.0),
        ));
        commands.spawn((
            Mesh3d(spire.clone()),
            MeshMaterial3d(pillar_mat.clone()),
            Transform::from_translation(p + Vec3::Y * 15.5),
        ));
    }

    // Четыре голубых «фонаря души» (всего 4 точечных света — бюджет для мобилок)
    for i in 0..4 {
        let a = i as f32 / 4.0 * TAU + TAU / 8.0;
        let p = Vec3::new(a.cos(), 0.0, a.sin()) * (ARENA_R - 3.0);
        commands.spawn((
            PointLight {
                color: theme::SOUL,
                intensity: 450_000.0,
                range: 16.0,
                shadows_enabled: false,
                ..default()
            },
            Transform::from_translation(p + Vec3::Y * 3.5),
        ));
    }

    commands.spawn((
        DirectionalLight {
            color: Color::srgb(0.6, 0.7, 1.0),
            illuminance: 1200.0,
            shadows_enabled: false,
            ..default()
        },
        Transform::from_xyz(4.0, 10.0, 2.0).looking_at(Vec3::ZERO, Vec3::Y),
    ));
}
