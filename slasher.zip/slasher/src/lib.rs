//! Hollow Arena — выживание от первого лица в мрачном мире жуков (стиль Devil Daggers).
//! Точка входа для ПК (`main.rs`) и для Android (`android_main` через `bevy_main`).
mod arena;
mod combat;
mod enemies;
mod input;
mod player;
mod theme;
mod ui;

use bevy::prelude::*;
use bevy::window::AppLifecycle;

#[derive(States, Default, Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum GameState {
    #[default]
    Playing,
    Dead,
    /// Сворачивание приложения / ручная пауза
    Paused,
}

pub fn build_app() -> App {
    let mut app = App::new();
    app.add_plugins(DefaultPlugins.set(WindowPlugin {
        primary_window: Some(Window {
            title: "Hollow Arena".into(),
            ..default()
        }),
        ..default()
    }))
    .insert_resource(ClearColor(theme::VOID))
    .init_state::<GameState>()
    .add_plugins((
        input::InputPlugin,
        player::PlayerPlugin,
        arena::ArenaPlugin,
        combat::CombatPlugin,
        enemies::EnemyPlugin,
        ui::UiPlugin,
    ))
    .add_systems(Update, handle_lifecycle);
    app
}

/// Android: при сворачивании ставим игру на паузу, чтобы не сжигать батарею
/// и не потерять забег; возобновление — тапом.
fn handle_lifecycle(
    mut events: MessageReader<AppLifecycle>,
    state: Res<State<GameState>>,
    mut next: ResMut<NextState<GameState>>,
) {
    for e in events.read() {
        if matches!(e, AppLifecycle::WillSuspend | AppLifecycle::Suspended)
            && *state.get() == GameState::Playing
        {
            next.set(GameState::Paused);
        }
    }
}

#[cfg(target_os = "android")]
#[bevy_main]
pub fn main() {
    build_app().run();
}
