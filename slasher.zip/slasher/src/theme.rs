//! Палитра в духе Hollow Knight: почти монохром, холодная тьма, бледная кость,
//! голубая «душа» и редкие вспышки оранжевой заразы.
use bevy::prelude::*;

pub const VOID: Color = Color::srgb(0.015, 0.02, 0.035);
pub const FOG: Color = Color::srgb(0.03, 0.04, 0.07);
pub const STONE: Color = Color::srgb(0.10, 0.12, 0.17);
pub const PILLAR: Color = Color::srgb(0.22, 0.25, 0.32);
pub const BONE: Color = Color::srgb(0.88, 0.86, 0.80);
pub const SOUL: Color = Color::srgb(0.55, 0.80, 1.00);
pub const INFECTION: Color = Color::srgb(1.00, 0.45, 0.10);
pub const RALLY: Color = Color::srgb(0.95, 0.70, 0.35);
pub const UI_BACK: Color = Color::srgba(0.02, 0.03, 0.05, 0.75);
