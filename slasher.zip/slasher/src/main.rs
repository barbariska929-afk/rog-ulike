fn main() {
    slasher::build_app().run();
}
