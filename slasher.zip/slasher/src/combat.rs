//! Стрельба иглами души (в духе Devil Daggers): удерживай огонь — игла за иглой.
//! Каждые 10 убитых врагов («самоцветы») добавляют ещё одну иглу в залп.
use crate::enemies::{Enemy, RunRng};
use crate::input::{GameInput, InputSet};
use crate::player::{PlayerCam, ARENA_R};
use crate::{theme, GameState};
use bevy::prelude::*;
use rand::Rng;

const FIRE_INTERVAL: f32 = 0.11;
const NEEDLE_SPEED: f32 = 55.0;
const NEEDLE_LIFE: f32 = 1.0;
const GEMS_PER_LEVEL: u32 = 10;
const MAX_LEVEL: u32 = 6;

#[derive(Component)]
pub struct Needle {
    vel: Vec3,
    life: f32,
}

#[derive(Resource, Default)]
pub struct Gun {
    pub cd: f32,
    pub gems: u32,
}

impl Gun {
    /// Сколько игл в залпе.
    pub fn level(&self) -> u32 {
        (1 + self.gems / GEMS_PER_LEVEL).min(MAX_LEVEL)
    }
}

#[derive(Resource)]
struct NeedleAssets {
    mesh: Handle<Mesh>,
    mat: Handle<StandardMaterial>,
}

pub struct CombatPlugin;

impl Plugin for CombatPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<Gun>()
            .add_systems(Startup, setup_assets)
            .add_systems(
                Update,
                (fire, move_needles)
                    .chain()
                    .after(InputSet)
                    .run_if(in_state(GameState::Playing)),
            );
    }
}

fn setup_assets(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
) {
    commands.insert_resource(NeedleAssets {
        mesh: meshes.add(Cuboid::new(0.035, 0.035, 0.7)),
        mat: materials.add(StandardMaterial {
            base_color: theme::SOUL,
            emissive: LinearRgba::rgb(1.2, 3.0, 5.0),
            unlit: true,
            ..default()
        }),
    });
}

fn fire(
    time: Res<Time>,
    input: Res<GameInput>,
    assets: Res<NeedleAssets>,
    mut gun: ResMut<Gun>,
    mut rng: ResMut<RunRng>,
    cam: Query<&GlobalTransform, With<PlayerCam>>,
    mut commands: Commands,
) {
    gun.cd -= time.delta_secs();
    if !input.fire || gun.cd > 0.0 {
        return;
    }
    let Ok(cam) = cam.single() else { return };
    gun.cd = FIRE_INTERVAL;

    let fwd: Vec3 = *cam.forward();
    let right: Vec3 = *cam.right();
    let up: Vec3 = *cam.up();
    let origin = cam.translation() + fwd * 0.7 + right * 0.22 - up * 0.18;

    let n = gun.level();
    let spread = 0.015 + 0.012 * n as f32;
    for i in 0..n {
        // первая игла летит точно в прицел, остальные веером
        let s = if i == 0 { 0.0 } else { spread };
        let dir = (fwd + right * rng.0.gen_range(-s..=s) + up * rng.0.gen_range(-s..=s))
            .normalize_or(fwd);
        commands.spawn((
            Needle { vel: dir * NEEDLE_SPEED, life: NEEDLE_LIFE },
            Mesh3d(assets.mesh.clone()),
            MeshMaterial3d(assets.mat.clone()),
            Transform::from_translation(origin).looking_to(dir, Vec3::Y),
        ));
    }
}

fn move_needles(
    time: Res<Time>,
    mut commands: Commands,
    mut needles: Query<(Entity, &mut Transform, &mut Needle), Without<Enemy>>,
    mut enemies: Query<(&Transform, &mut Enemy), Without<Needle>>,
) {
    let dt = time.delta_secs();
    for (ent, mut tf, mut n) in &mut needles {
        n.life -= dt;
        let step = n.vel * dt;
        tf.translation += step;
        let p = tf.translation;

        let out = Vec2::new(p.x, p.z).length() > ARENA_R + 2.0;
        if n.life <= 0.0 || p.y < 0.0 || out {
            commands.entity(ent).despawn();
            continue;
        }

        for (et, mut e) in &mut enemies {
            if e.hp <= 0.0 {
                continue;
            }
            let center = et.translation + Vec3::Y * e.scale;
            if center.distance(p) < 0.85 * e.scale + 0.15 {
                e.hp -= 1.0;
                e.knock = Vec3::new(step.x, 0.0, step.z).normalize_or_zero() * 3.0;
                e.stagger = 0.06;
                commands.entity(ent).despawn();
                break;
            }
        }
    }
}
