//! Игрок: вид от первого лица, движение и дэш с короткой неуязвимостью.
//! Здоровья нет — любое попадание врага означает смерть (как в Devil Daggers).
use crate::{theme, GameState};
use crate::input::{GameInput, InputSet};
use bevy::pbr::{DistanceFog, FogFalloff};
use bevy::prelude::*;

pub const ARENA_R: f32 = 20.0;
pub const EYE_H: f32 = 1.6;

#[derive(Component)]
pub struct Player;

#[derive(Component)]
pub struct PlayerCam;

#[derive(Resource)]
pub struct PlayerState {
    pub yaw: f32,
    pub pitch: f32,
    pub vel: Vec3,
    pub dash_t: f32,
    pub dash_cd: f32,
    pub dash_dir: Vec3,
    pub iframes: f32,
}

impl Default for PlayerState {
    fn default() -> Self {
        Self {
            yaw: 0.0,
            pitch: 0.0,
            vel: Vec3::ZERO,
            dash_t: 0.0,
            dash_cd: 0.0,
            dash_dir: Vec3::NEG_Z,
            iframes: 0.0,
        }
    }
}

/// Тряска камеры.
#[derive(Resource, Default)]
pub struct Shake(pub f32);

pub struct PlayerPlugin;

impl Plugin for PlayerPlugin {
    fn build(&self, app: &mut App) {
        app.init_resource::<PlayerState>()
            .init_resource::<Shake>()
            .add_systems(Startup, spawn_player)
            .add_systems(
                Update,
                player_look_move
                    .after(InputSet)
                    .run_if(in_state(GameState::Playing)),
            );
    }
}

fn spawn_player(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<StandardMaterial>>,
) {
    // «Реликвия» в руке — светящийся кристалл, из которого вылетают иглы
    let relic = meshes.add(Cuboid::new(0.08, 0.08, 0.3));
    let relic_mat = materials.add(StandardMaterial {
        base_color: theme::BONE,
        emissive: LinearRgba::rgb(0.6, 1.4, 2.4),
        ..default()
    });

    commands
        .spawn((Player, Transform::default(), Visibility::default()))
        .with_children(|p| {
            p.spawn((
                PlayerCam,
                Camera3d::default(),
                Msaa::Off, // MSAA на мобилках дорогой
                DistanceFog {
                    color: theme::FOG,
                    falloff: FogFalloff::Linear { start: 8.0, end: 34.0 },
                    ..default()
                },
                Transform::from_xyz(0.0, EYE_H, 0.0),
            ))
            .with_children(|c| {
                c.spawn((
                    Mesh3d(relic),
                    MeshMaterial3d(relic_mat),
                    Transform::from_xyz(0.26, -0.24, -0.55),
                ));
            });
        });
}

fn player_look_move(
    time: Res<Time>,
    input: Res<GameInput>,
    mut st: ResMut<PlayerState>,
    mut shake: ResMut<Shake>,
    mut player: Query<&mut Transform, With<Player>>,
    mut cam: Query<&mut Transform, (With<PlayerCam>, Without<Player>)>,
) {
    let dt = time.delta_secs();
    let (Ok(mut pt), Ok(mut ct)) = (player.single_mut(), cam.single_mut()) else { return };

    st.yaw -= input.look.x;
    st.pitch = (st.pitch - input.look.y).clamp(-1.2, 1.2);
    pt.rotation = Quat::from_rotation_y(st.yaw);

    let fwd = pt.rotation * Vec3::NEG_Z;
    let right = pt.rotation * Vec3::X;
    let wish = (fwd * input.move_axis.y + right * input.move_axis.x).clamp_length_max(1.0);

    st.dash_cd -= dt;
    st.iframes -= dt;
    if input.dash && st.dash_cd <= 0.0 && st.dash_t <= 0.0 {
        st.dash_dir = if wish.length_squared() > 0.01 { wish.normalize() } else { fwd };
        st.dash_t = 0.16;
        st.dash_cd = 1.1;
        st.iframes = 0.25;
    }

    if st.dash_t > 0.0 {
        st.dash_t -= dt;
        st.vel = st.dash_dir * 24.0;
    } else {
        let k = 1.0 - (-12.0 * dt).exp();
        st.vel = st.vel.lerp(wish * 8.0, k);
    }

    pt.translation += st.vel * dt;
    let flat = Vec2::new(pt.translation.x, pt.translation.z);
    if flat.length() > ARENA_R - 1.0 {
        let c = flat.normalize() * (ARENA_R - 1.0);
        pt.translation.x = c.x;
        pt.translation.z = c.y;
    }

    shake.0 = (shake.0 - dt * 0.6).max(0.0);
    let t = time.elapsed_secs();
    let off = Vec3::new((t * 61.0).sin(), (t * 73.0).cos(), 0.0) * shake.0 * 0.15;
    ct.rotation = Quat::from_rotation_x(st.pitch);
    ct.translation = Vec3::new(0.0, EYE_H, 0.0) + off;
}
