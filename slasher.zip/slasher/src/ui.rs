//! HUD (время выживания, залп, убийства), сенсорные кнопки и экраны смерти/паузы.
use crate::combat::{Gun, Needle};
use crate::enemies::{Enemy, Run};
use crate::input::{GameInput, TouchButton, ATTACK_BTN, DASH_BTN};
use crate::player::{Player, PlayerState};
use crate::{theme, GameState};
use bevy::prelude::*;
use bevy::state::state_scoped::DespawnOnExit;

#[derive(Component)]
enum HudText {
    Time,
    Info,
}

pub struct UiPlugin;

impl Plugin for UiPlugin {
    fn build(&self, app: &mut App) {
        app.add_systems(Startup, spawn_hud)
            .add_systems(Update, update_hud)
            .add_systems(OnEnter(GameState::Dead), spawn_dead)
            .add_systems(OnEnter(GameState::Paused), spawn_paused)
            .add_systems(
                Update,
                (
                    restart_on_tap.run_if(in_state(GameState::Dead)),
                    resume_on_tap.run_if(in_state(GameState::Paused)),
                ),
            );
    }
}

fn font(size: f32) -> TextFont {
    TextFont { font_size: size, ..default() }
}

fn spawn_hud(mut commands: Commands) {
    // Таймер выживания по центру сверху — главный счёт
    commands
        .spawn(Node {
            position_type: PositionType::Absolute,
            top: Val::Px(10.0),
            width: Val::Percent(100.0),
            justify_content: JustifyContent::Center,
            ..default()
        })
        .with_children(|p| {
            p.spawn((Text::new("0.0"), font(44.0), TextColor(theme::BONE), HudText::Time));
        });

    // Залп и убийства слева сверху
    commands.spawn((
        Text::new(""),
        font(18.0),
        TextColor(theme::SOUL),
        Node {
            position_type: PositionType::Absolute,
            left: Val::Px(16.0),
            top: Val::Px(16.0),
            ..default()
        },
        HudText::Info,
    ));

    // Прицел
    commands.spawn((
        Node {
            position_type: PositionType::Absolute,
            left: Val::Percent(50.0),
            top: Val::Percent(50.0),
            width: Val::Px(5.0),
            height: Val::Px(5.0),
            margin: UiRect::all(Val::Px(-2.5)),
            ..default()
        },
        BackgroundColor(theme::BONE.with_alpha(0.6)),
    ));

    // Сенсорные кнопки (геометрия общая с обработчиком ввода)
    for (b, label) in [(ATTACK_BTN, "FIRE"), (DASH_BTN, "DASH")] {
        spawn_touch_button(&mut commands, b, label);
    }
}

fn spawn_touch_button(commands: &mut Commands, b: TouchButton, label: &str) {
    commands
        .spawn((
            Node {
                position_type: PositionType::Absolute,
                right: Val::Px(b.right),
                bottom: Val::Px(b.bottom),
                width: Val::Px(b.size),
                height: Val::Px(b.size),
                justify_content: JustifyContent::Center,
                align_items: AlignItems::Center,
                border: UiRect::all(Val::Px(2.0)),
                border_radius: BorderRadius::MAX,
                ..default()
            },
            BackgroundColor(theme::UI_BACK),
            BorderColor::all(theme::SOUL.with_alpha(0.7)),
        ))
        .with_children(|p| {
            p.spawn((Text::new(label), font(16.0), TextColor(theme::BONE)));
        });
}

fn update_hud(run: Res<Run>, gun: Res<Gun>, mut texts: Query<(&mut Text, &HudText)>) {
    for (mut t, kind) in &mut texts {
        t.0 = match kind {
            HudText::Time => format!("{:.1}", run.time),
            HudText::Info => format!("NEEDLES x{}   KILLS {}", gun.level(), run.kills),
        };
    }
}

fn overlay_root() -> Node {
    Node {
        position_type: PositionType::Absolute,
        width: Val::Percent(100.0),
        height: Val::Percent(100.0),
        flex_direction: FlexDirection::Column,
        justify_content: JustifyContent::Center,
        align_items: AlignItems::Center,
        row_gap: Val::Px(14.0),
        ..default()
    }
}

fn spawn_dead(mut commands: Commands, run: Res<Run>) {
    let record = run.time >= run.best && run.time > 0.0;
    commands
        .spawn((
            overlay_root(),
            BackgroundColor(Color::srgba(0.01, 0.01, 0.02, 0.82)),
            DespawnOnExit(GameState::Dead),
        ))
        .with_children(|p| {
            p.spawn((Text::new("THE HOLLOW CLAIMS YOU"), font(36.0), TextColor(theme::INFECTION)));
            p.spawn((
                Text::new(format!("You lasted {:.1} s   |   {} foes", run.time, run.kills)),
                font(24.0),
                TextColor(theme::BONE),
            ));
            let line = if record {
                "NEW RECORD".to_string()
            } else {
                format!("Best: {:.1} s", run.best)
            };
            p.spawn((Text::new(line), font(20.0), TextColor(theme::RALLY)));
            p.spawn((Text::new("tap to rise again"), font(18.0), TextColor(theme::SOUL)));
        });
}

fn spawn_paused(mut commands: Commands) {
    commands
        .spawn((
            overlay_root(),
            BackgroundColor(Color::srgba(0.01, 0.01, 0.02, 0.7)),
            DespawnOnExit(GameState::Paused),
        ))
        .with_children(|p| {
            p.spawn((Text::new("PAUSED"), font(36.0), TextColor(theme::BONE)));
            p.spawn((Text::new("tap to continue"), font(18.0), TextColor(theme::SOUL)));
        });
}

fn restart_on_tap(
    time: Res<Time>,
    input: Res<GameInput>,
    mut since: Local<f32>,
    mut commands: Commands,
    clear: Query<Entity, Or<(With<Enemy>, With<Needle>)>>,
    mut player: Query<&mut Transform, With<Player>>,
    mut run: ResMut<Run>,
    mut gun: ResMut<Gun>,
    mut pst: ResMut<PlayerState>,
    mut next: ResMut<NextState<GameState>>,
) {
    *since += time.delta_secs();
    // небольшая задержка, чтобы тап в момент смерти не перезапустил забег
    if !input.tap || *since < 0.8 {
        return;
    }
    *since = 0.0;

    for e in &clear {
        commands.entity(e).despawn();
    }
    if let Ok(mut t) = player.single_mut() {
        *t = Transform::default();
    }
    let best = run.best;
    *run = Run { best, spawn_t: 1.0, ..default() };
    *gun = Gun::default();
    *pst = PlayerState::default();
    next.set(GameState::Playing);
}

fn resume_on_tap(input: Res<GameInput>, mut next: ResMut<NextState<GameState>>) {
    if input.tap {
        next.set(GameState::Playing);
    }
}
